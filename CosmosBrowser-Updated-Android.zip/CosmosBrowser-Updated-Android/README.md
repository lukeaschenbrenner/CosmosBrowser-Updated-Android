# This project has been deprecated. We are currently working on a better version of Cosmos Browser that will utilize a peer-to-peer  internet over SMS protocol that we will release soon. Please stay tuned.

CosmosBrowserAndroid
====================
Cosmos Browser allows the user to connect to the internet through the use of SMS. No data or WiFi required.

### Made with <3 at MHacks IV



